import Login from './screens/Login';

const App = () => {
  return <Login />;
};

export default App;
