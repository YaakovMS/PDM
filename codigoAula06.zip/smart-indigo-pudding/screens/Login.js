import React from 'react'; // Import React
import { View } from 'react-native';
import { Text, TextInput, HelperText, Button } from 'react-native-paper';
import { useForm, Controller } from 'react-hook-form';

const Login = () => {
  const { control, handleSubmit, formState: { errors } } = useForm();

  const onSubmit = (data) => console.log(data);

  return (
    <View style={{ flex: 1, justifyContent: 'center', padding: 16 }}>
      <Text style={{ fontSize: 32, textAlign: 'center' }}>Login</Text>
      <Controller
        control={control}
        rules={{ required: 'Email obrigatório' }} // Simplified the rules
        render={({ field: { onChange, value } }) => (
          <TextInput
            label={'Email'}
            mode={'outlined'}
            onChangeText={(text) => onChange(text)} // Updated to use onChange
            keyboardType={'email-address'}
            value={value}
          />
        )}
        name={'email'}
      />
      <HelperText type="error" visible={errors.email !== undefined}>
        {errors.email && errors.email.message}
      </HelperText>
      <Controller
        control={control}
        rules={{ required: 'Senha obrigatória' }} // Simplified the rules
        render={({ field: { onChange, value } }) => (
          <TextInput
            label={'Senha'}
            mode={'outlined'}
            onChangeText={(text) => onChange(text)} // Updated to use onChange
            secureTextEntry={true}
            value={value}
          />
        )}
        name="senha"
      />
      <HelperText type="error" visible={errors.senha !== undefined}>
        {errors.senha && errors.senha.message}
      </HelperText>
      <Button mode={'contained'} onPress={handleSubmit(onSubmit)}>
        Entrar
      </Button>
    </View>
  );
};

export default Login;

