import React from 'react';
import { Text, SafeAreaView, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/native-stack';

import MainNavigator from './routes/MainNavigator';
import ContatoProvider  from './context/ContatoContext'

const Stack = createStackNavigator();

export default function App() {
  return (
    <SafeAreaView>
      <NavigationContainer>
      <ContatoProvider>
      <MainNavigator/>
      </ContatoProvider>
      </NavigationContainer>
    </SafeAreaView>
  );
}
