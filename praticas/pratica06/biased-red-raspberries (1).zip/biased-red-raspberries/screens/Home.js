import React, { useContext } from 'react';
import { View, Text, FlatList, Button } from 'react-native';
import { ContatoContext } from '../context/ContatoContext';

const Home = ({ navigation }) => {
  const { contatos } = useContext(ContatoContext);

  return (
    <View style={{ flex: 1, padding: 16 }}>
      <Text style={{ fontSize: 24, marginBottom: 16 }}>@Contatinhos</Text>

      <FlatList
        data={contatos}
        renderItem={({ item }) => (
          <View style={{ marginBottom: 8 }}>
            <Text>{item}</Text>
          </View>
        )}
      />

      <Button
        title="Adicionar Contato"
        onPress={() => navigation.navigate('Novo')}
      />
    </View>
  );
}

export default Home;
