import React, { useState } from 'react';
import { View, TextInput, Button } from 'react-native';

const Novo = ({ navigation }) => {
  const [contato, setContato] = useState('');

  return (
    <View style={{ flex: 1, padding: 16 }}>
      <TextInput
        placeholder="Nome"
        value={contato}
        onChangeText={(text) => setContato(text)}
      />

      <Button title="Salvar" onPress={() => navigation.navigate('Home')} />
    </View>
  );
}

export default Novo;
